package jdbcTwitter;

import javax.swing.SwingUtilities;

public class start {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Login(); // 로그인 창을 시작
            }
        });
    }
}
