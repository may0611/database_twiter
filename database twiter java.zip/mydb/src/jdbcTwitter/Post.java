package jdbcTwitter;

public class Post {
    private String id;       // 게시물의 ID
    private String content;  // 게시물 내용
    private String writer;   // 게시물 작성자
    private String date;     // 게시 날짜
    private int likes;       // 좋아요 수

    public Post(String id, String content, String writer, String date) {
        this.id = id;
        this.content = content;
        this.writer = writer;
        this.date = date;
        this.likes = 0; // 초기 좋아요 수는 0으로 설정
    }

    public String getId() {
        return id;
    }

    public String getContent() {
        return content;
    }

    public String getWriter() {
        return writer;
    }

    public String getDate() {
        return date;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    // 필요에 따라 추가 메서드 구현...
}