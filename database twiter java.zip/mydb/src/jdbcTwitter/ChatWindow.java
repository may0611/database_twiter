package jdbcTwitter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class ChatWindow extends JFrame {
    private JTextArea messageArea;
    private JTextField messageField;
    private String userId;
    private String chatPartnerId;
    private Socket socket;
    private PrintWriter out;
    private dbAccess db; // 데이터베이스 접근 객체

    public ChatWindow(String userId, String chatPartnerId, dbAccess db) {
        this.userId = userId;
        this.chatPartnerId = chatPartnerId;
        this.db = db;

        // GUI 구성
        messageArea = new JTextArea(8, 40);
        messageField = new JTextField(40);
        messageField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendMessage(messageField.getText());
                messageField.setText("");
            }
        });

        setLayout(new BorderLayout());
        add(new JScrollPane(messageArea), BorderLayout.CENTER);
        add(messageField, BorderLayout.SOUTH);
        pack();
        setTitle("Chat with " + chatPartnerId);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        connectToServer();
    }
    
    private void connectToServer() {
        try {
            socket = new Socket("localhost", 9001);
            out = new PrintWriter(socket.getOutputStream(), true);
            out.println(userId); // 서버에 사용자 ID 전송

            new Thread(new IncomingReader()).start();
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "서버 연결에 실패했습니다.", "연결 오류", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void sendMessage(String message) {
        if (message != null && !message.trim().isEmpty()) {
            out.println(message);
            db.saveMessage(userId, chatPartnerId, message); // DB에 메시지 저장
        }
    }

    private class IncomingReader implements Runnable {
        public void run() {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String message;
                while ((message = reader.readLine()) != null) {
                    messageArea.append(message + "\n");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}